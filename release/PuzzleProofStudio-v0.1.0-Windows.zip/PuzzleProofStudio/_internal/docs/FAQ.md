# PuzzleProof Studio FAQ

## Getting Started

### What is PuzzleProof Studio?

PuzzleProof Studio is a desktop production tool for managing artist approvals, puzzle project records, image exports, catalog data, and print-ready production documents.

### What should I do first?

Start in the Project tab, enter the artist and artwork details, confirm the approval status, then save the project before exporting images or printing documents.

## Licensing

### How does licensing work?

PuzzleProof Studio uses an offline yearly license file. During Early Access, the app can fall back to the included sample license so testing is not blocked.

### Where do I put license.json?

Place a private license file at `licenses/license.json`. Do not share or commit private license files.

## Projects

### Where are project records saved?

Saved project JSON files are stored under the `jobs` folder, with catalog metadata also written to `catalog/catalog.json`.

### What is Manufacturing Ready?

Manufacturing Ready means the project has the required approval, artwork, copyright owner, and export information needed before production.

## Catalog

### How do I find a saved project?

Use the Catalog tab to search by artist name, artwork title, or catalog ID. Use Show All to reset filters.

### Can multiple users edit the catalog at once?

Not in this Early Access build. Catalog storage is local JSON, so treat it as a single-user workflow.

## Printing

### What does the Printing tab create?

It creates print-ready HTML files for artist releases, copyright forms, production sheets, stickers, inserts, puzzle covers, and production packages.

### Does it print directly to my printer?

The current workflow creates print-ready files and opens folders for review. Native printer selection can be added later.

## Production Packages

### What is a production package?

A production package generates the full set of print-ready production documents for the current project.

### Where are production package files saved?

Generated files are saved in the `exports` folder.

## Troubleshooting

### The app will not open. What should I check?

Confirm Python and Tkinter are installed for source runs, or use the Windows packaged executable after it has been built and tested on Windows.

### My export failed. What should I check?

Confirm a source image is selected and that the image file still exists at the path shown in the Image Conversion tab.

## Support

### How do I contact support?

Use Help > Contact Support, copy the Support tab information, and include the project steps that led to the problem.

### Where do I report a bug?

Use Help > Report Issue to open the GitHub issue tracker:

https://github.com/dewaynecox123456-lang/puzzleproof-studio/issues
